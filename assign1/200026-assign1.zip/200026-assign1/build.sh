#!/bin/bash

# NOTE:
# (1) Replace "lexer_name" string with the path of the lexer file
# (2) Replace "testcases_folder_path" string with the path of the testcases folder

lexer_name="./problem1/lex.l" # Replace with the path of the lexer file
testcases_folder_path="./problem1-testcases" # Replace with the path to the folder containing the input files

program_name="scan" # Replace with the name of your program
execute_program="./"$program_name
csv_name="_result.csv" # Replace with the name of your csv file
result_folder_path=$testcases_folder_path"_result" # Replace with the path to the folder containing the result files

chmod +x build.sh # Adding execute permissions for script

if [ ! -d "$result_folder_path" ]; then
  mkdir $result_folder_path
fi

flex $lexer_name
g++ -o $program_name lex.yy.c -ll

for file in $testcases_folder_path/*; do
    echo "Running program with input from file: $file"
    result_path=$result_folder_path"/"$(basename $file)$csv_name
    $execute_program $result_path < $file
done